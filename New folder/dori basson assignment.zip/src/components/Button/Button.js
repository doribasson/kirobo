import React from "react";

const Buttom = () => {
  return (
    <button id="submit" className="btn-submit">
      Login
    </button>
  );
};

export default Buttom;
